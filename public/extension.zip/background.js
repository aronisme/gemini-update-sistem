
chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension installed");
});
