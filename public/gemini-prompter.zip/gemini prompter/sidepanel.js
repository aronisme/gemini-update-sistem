// Gemini Prompt Generator - New Side Panel Logic

// ============================================================================
// GLOBAL VARIABLES & CONSTANTS
// ============================================================================

const MODELS = {
    PRIMARY: 'gemini-2.5-flash',
    BACKUP_1: 'gemini-2.5-flash-lite'
};

const API_URL_TEMPLATE = 'https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent?key=';
const MAX_IMAGES_PER_SESSION = 25;
const DELAY_BETWEEN_REQUESTS = 2000;

// State
let apiKeys = [];
let keyIndex = 0;
let fileQueue = [];
let scrapedImages = [];
let processing = false;
let currentModel = MODELS.PRIMARY;
let currentMagicPrompts = [];

// DOM Elements Cache
let els = {};

document.addEventListener('DOMContentLoaded', () => {
    initializeElements();
    setupEventListeners();
    loadApiKeys();
    checkForUpdates();
});

function initializeElements() {
    els = {
        // Tabs
        tabs: document.querySelectorAll('.tab-button'),
        tabContents: document.querySelectorAll('.tab-content'),

        // API Status
        apiStatusContainer: document.getElementById('apiStatusContainer'),
        apiStatusText: document.getElementById('apiStatusText'),
        configureApiButtonLink: document.getElementById('configureApiButtonLink'),

        // Scrape & Upload
        scrapeButton: document.getElementById('scrapeButton'),
        scrapedImagesContainer: document.getElementById('scrapedImagesContainer'),
        scrapedImagesGrid: document.getElementById('scrapedImagesGrid'),
        selectAllButton: document.getElementById('selectAllButton'),
        deselectAllButton: document.getElementById('deselectAllButton'),
        imageUpload: document.getElementById('imageUpload'),
        fileCount: document.getElementById('fileCount'),

        // Config & Actions
        globalStyleSelect: document.getElementById('globalStyleSelect'),
        queueStatus: document.getElementById('queueStatus'),
        clearQueueButton: document.getElementById('clearQueueButton'),
        startButton: document.getElementById('startButton'),
        downloadButton: document.getElementById('downloadButton'),

        // Results
        resultsContainer: document.getElementById('resultsContainer'),

        // Magic Tab
        magicInput: document.getElementById('magicInput'),
        magicStyleSelect: document.getElementById('magicStyleSelect'),
        magicCountInput: document.getElementById('magicCountInput'),
        magicGenerateButton: document.getElementById('magicGenerateButton'),
        magicDownloadButton: document.getElementById('magicDownloadButton'),
        magicResultsList: document.getElementById('magicResultsList'),

        // Settings
        newApiKeyInput: document.getElementById('newApiKeyInput'),
        addApiKeyButton: document.getElementById('addApiKeyButton'),
        apiKeyListContainer: document.getElementById('apiKeyListContainer'),
        minImageSizeInput: document.getElementById('minImageSize'),
        autoOpenPanelInput: document.getElementById('autoOpenPanel'),
        autoOpenPanelInput: document.getElementById('autoOpenPanel'),

        // Modal
        loadingModal: document.getElementById('loadingModal'),
        loadingText: document.getElementById('loadingText'),

        // Stats
        apiKeyCount: document.getElementById('apiKeyCount'),

        // Toast
        toastContainer: document.getElementById('toastContainer'),

        // Trends
        trendsTabButton: document.getElementById('trendsTabButton'),
        refreshTrendsButton: document.getElementById('refreshTrendsButton'),
        trendsLoading: document.getElementById('trendsLoading'),
        trendsList: document.getElementById('trendsList'),

        // Update Banner
        updateContainer: document.getElementById('updateContainer'),
        updateNotes: document.getElementById('updateNotes'),
        updateDownloadLink: document.getElementById('updateDownloadLink'),

        // Settings Update Section
        settingsCurrentVersion: document.getElementById('settingsCurrentVersion'),
        settingsUpdateStatus: document.getElementById('settingsUpdateStatus'),
        settingsUpdateAction: document.getElementById('settingsUpdateAction'),
        settingsUpdateNotes: document.getElementById('settingsUpdateNotes'),
        settingsDownloadLink: document.getElementById('settingsDownloadLink')
    };
}

function setupEventListeners() {
    // Tab Switching
    els.tabs.forEach(tab => {
        tab.addEventListener('click', () => switchTab(tab.dataset.tab));
    });

    els.configureApiButtonLink.addEventListener('click', () => switchTab('settings'));

    // Scraper
    els.scrapeButton.addEventListener('click', scrapeImagesFromPage);
    els.selectAllButton.addEventListener('click', () => toggleAllScrapedImages(true));
    els.deselectAllButton.addEventListener('click', () => toggleAllScrapedImages(false));

    // Upload
    els.imageUpload.addEventListener('change', handleFileUpload);

    // Queue Actions
    els.startButton.addEventListener('click', processQueue);
    els.downloadButton.addEventListener('click', () => {
        downloadAllPrompts();
        els.downloadButton.classList.remove('btn-highlight-infinite');
    });
    els.clearQueueButton.addEventListener('click', clearQueue);

    // Magic Tab
    els.magicGenerateButton.addEventListener('click', generateMagicPrompt);
    els.magicDownloadButton.addEventListener('click', () => {
        downloadMagicPrompts();
        els.magicDownloadButton.classList.remove('btn-highlight-infinite');
    });

    // Trends Tab
    if (els.refreshTrendsButton) {
        els.refreshTrendsButton.addEventListener('click', fetchTrendingSearches);
    }

    // Settings
    els.addApiKeyButton.addEventListener('click', addApiKey);
    // Settings
    els.addApiKeyButton.addEventListener('click', addApiKey);

    // Auto-save specific preferences
    els.minImageSizeInput.addEventListener('change', () => {
        console.log('Min size updated:', els.minImageSizeInput.value);
    });
}

// ============================================================================
// UI LOGIC
// ============================================================================

function switchTab(tabName) {
    els.tabs.forEach(t => {
        if (t.dataset.tab === tabName) {
            t.classList.remove('text-slate-500', 'border-transparent');
            t.classList.add('text-brand-600', 'border-brand-600', 'active');
        } else {
            t.classList.add('text-slate-500', 'border-transparent');
            t.classList.remove('text-brand-600', 'border-brand-600', 'active');
        }
    });

    els.tabContents.forEach(c => {
        if (c.id === `${tabName}Tab`) {
            c.classList.add('active');
        } else {
            c.classList.remove('active');
        }
    });
}

function showLoading(text) {
    els.loadingText.textContent = text;
    els.loadingModal.classList.remove('hidden');
}

function hideLoading() {
    els.loadingModal.classList.add('hidden');
}

function updateQueueStatus() {
    const total = fileQueue.length;

    if (total > 0) {
        els.queueStatus.textContent = `${total} image${total > 1 ? 's' : ''} ready`;
        els.queueStatus.classList.add('text-brand-600', 'font-bold');
        els.queueStatus.classList.remove('text-slate-500');
        els.startButton.disabled = false;
        els.clearQueueButton.classList.remove('hidden');
    } else {
        els.queueStatus.textContent = "Ready to process";
        els.queueStatus.classList.remove('text-brand-600', 'font-bold');
        els.queueStatus.classList.add('text-slate-500');
        els.startButton.disabled = true;
        els.clearQueueButton.classList.add('hidden');
    }
}

function renderApiKeysList() {
    els.apiKeyListContainer.innerHTML = '';

    // Update count display
    if (els.apiKeyCount) {
        els.apiKeyCount.textContent = `${apiKeys.length} Active Key(s)`;
    }

    if (apiKeys.length === 0) {
        els.apiKeyListContainer.innerHTML = '<p class="text-xs text-slate-400 text-center py-4">No keys added yet.</p>';
        // Show warning in dashboard
        els.apiStatusContainer.classList.remove('hidden');
    } else {
        // Hide warning in dashboard
        els.apiStatusContainer.classList.add('hidden');

        apiKeys.forEach((key, index) => {
            const div = document.createElement('div');
            div.className = 'api-key-item';
            div.innerHTML = `
                <span class="api-key-text">Key ${index + 1}: ...${key.substr(-4)}</span>
                <button class="api-key-delete" data-index="${index}">Delete</button>
            `;
            div.querySelector('button').addEventListener('click', () => deleteApiKey(index));
            els.apiKeyListContainer.appendChild(div);
        });
    }
}

// ============================================================================
// CORE LOGIC: SCRAPING & QUEUE
// ============================================================================

async function scrapeImagesFromPage() {
    showLoading('Scanning page for images...');
    els.scrapedImagesGrid.innerHTML = ''; // Clear previous

    try {
        const response = await chrome.runtime.sendMessage({ action: 'scrapeImages' });

        if (response && response.success && response.images) {
            scrapedImages = response.images;
            renderScrapedGrid(scrapedImages);
            if (scrapedImages.length > 0) {
                els.scrapedImagesContainer.classList.remove('hidden');
                showToast(`Found ${scrapedImages.length} images!`, 'success');
            } else {
                showToast('No suitable images found on this page.', 'error');
            }
        } else {
            console.error('Scrape failed:', response);
            showToast('Could not scrape images. Refresh page?', 'error');
        }
    } catch (e) {
        console.error(e);
        showToast('Error communicating with page.', 'error');
    } finally {
        hideLoading();
    }
}

function renderScrapedGrid(images) {
    els.scrapedImagesGrid.innerHTML = '';

    // Sort logic removed, keeping original order or filtering by size
    const minSize = parseInt(els.minImageSizeInput.value) || 100;

    images.forEach((img, index) => {
        if (img.width < minSize && img.height < minSize) return;

        const div = document.createElement('div');
        div.className = "image-card-wrapper group";
        div.dataset.index = index;

        div.innerHTML = `
            <img src="${img.url}" class="w-full h-full object-cover">
            <div class="overlay-checkbox hidden check-icon">
                <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"></polyline></svg>
            </div>
            <div class="img-dimension-badge">
                ${img.width}x${img.height}
            </div>
        `;

        div.onclick = () => toggleImageSelection(index, div, img);
        els.scrapedImagesGrid.appendChild(div);
    });
}

function toggleImageSelection(index, element, imgData) {
    const isSelected = element.classList.contains('selected');

    if (isSelected) {
        element.classList.remove('selected');
        element.querySelector('.check-icon').classList.add('hidden');
        removeFromQueueById(`scraped-${index}`);
    } else {
        element.classList.add('selected');
        element.querySelector('.check-icon').classList.remove('hidden');
        addToQueue({
            id: `scraped-${index}`,
            type: 'url',
            data: null,
            url: imgData.url,
            name: `Image ${index + 1}`
        });
    }
    updateQueueStatus();
}

function toggleAllScrapedImages(select) {
    const cards = els.scrapedImagesGrid.children;
    for (let card of cards) {
        const index = parseInt(card.dataset.index);
        const isSelected = card.classList.contains('selected');

        if (select && !isSelected) {
            card.click(); // Trigger click logic to select
        } else if (!select && isSelected) {
            card.click(); // Trigger click logic to deselect
        }
    }
}

function handleFileUpload(e) {
    const files = Array.from(e.target.files);
    if (!files.length) return;

    files.forEach(file => {
        addToQueue({
            id: `file-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            type: 'file',
            data: file,
            url: null,
            name: file.name
        });
    });

    els.fileCount.textContent = `${files.length} file(s) added manually`;
    els.fileCount.classList.remove('hidden');
    updateQueueStatus();
    showToast(`${files.length} files added to queue`, 'success');
    e.target.value = ''; // Reset input
}

function addToQueue(item) {
    // Check duplicates
    if (fileQueue.some(i => i.id === item.id)) return;
    fileQueue.push(item);
}

function removeFromQueueById(id) {
    fileQueue = fileQueue.filter(i => i.id !== id);
}

function clearQueue() {
    fileQueue = [];
    renderScrapedGrid(scrapedImages); // Resets grid selection visually
    els.fileCount.textContent = '';
    els.fileCount.classList.add('hidden');
    els.resultsContainer.classList.add('hidden');
    // Clear results UI
    const resultList = els.resultsContainer.querySelectorAll('.result-card');
    resultList.forEach(el => el.remove());
    updateQueueStatus();
}

// ============================================================================
// CORE LOGIC: API & GENERATION
// ============================================================================

async function processQueue() {
    if (processing || fileQueue.length === 0) return;
    if (apiKeys.length === 0) {
        showToast('Please add an API Key first!', 'error');
        switchTab('settings');
        return;
    }

    processing = true;
    showLoading('Initializing...');
    els.startButton.disabled = true;

    // Setup Results UI
    // Setup Results UI
    els.resultsContainer.classList.remove('hidden');

    let resultsList = document.getElementById('resultsList');
    if (!resultsList) {
        els.resultsContainer.innerHTML = '<div id="resultsList" class="space-y-3"></div>';
        resultsList = document.getElementById('resultsList');
    }
    const globalStyle = els.globalStyleSelect.value;

    // Create result cards first
    fileQueue.forEach(item => {
        // Skip if already has a result card (e.g. from retry)
        if (document.getElementById(`card-${item.id}`)) return;

        const card = createResultCard(item);
        resultsList.appendChild(card);
    });

    // Process Loop
    let successCount = 0;

    for (let i = 0; i < fileQueue.length; i++) {
        const item = fileQueue[i];
        if (item.status === 'completed') {
            successCount++;
            continue;
        }

        const card = document.getElementById(`card-${item.id}`);
        updateCardStatus(card, 'Processing...', 'text-brand-600');
        showLoading(`Processing ${i + 1} of ${fileQueue.length}...`);

        try {
            // Prepare Image
            let base64;
            let mimeType = 'image/jpeg';

            if (item.type === 'file') {
                base64 = await fileToBase64(item.data);
                mimeType = item.data.type;
            } else {
                base64 = await urlToBase64(item.url); // Use existing helper
            }

            // Generate
            const prompt = await generateWithGemini(base64, mimeType, globalStyle);

            item.prompt = prompt;
            item.status = 'completed';
            item.originalPrompt = prompt;

            // Update UI
            updateCardSuccess(card, prompt);
            successCount++;

            // Respect Rate Limits
            if (i < fileQueue.length - 1) await delay(DELAY_BETWEEN_REQUESTS);

        } catch (error) {
            console.error(error);
            item.status = 'failed';
            updateCardError(card, error.message);
        }
    }

    hideLoading();
    processing = false;
    els.startButton.disabled = false;

    if (successCount > 0) {
        els.downloadButton.disabled = false;
        els.downloadButton.classList.add('btn-highlight-infinite');
        showToast(`Generation complete! (${successCount}/${fileQueue.length})`, 'success');
    } else {
        showToast('Generation failed.', 'error');
    }
}

async function generateWithGemini(base64, mimeType, style) {
    if (apiKeys.length === 0) throw new Error("No API Keys configured");

    const systemPrompt = `Describe this image for an AI image generator.${style ? ' Style: ' + style : ''}. Keep it under 60 words. Focus on visual description.`;

    // Config: Models to try
    const models = Object.values(MODELS);

    let lastError = null;

    // Outer Loop: Try each Model
    for (const model of models) {

        // Inner Loop: Try up to 2 different API keys per model to avoid getting stuck
        // Start from current global index
        let localKeyAttempts = 0;
        const maxKeyAttempts = Math.min(apiKeys.length, 3);

        while (localKeyAttempts < maxKeyAttempts) {
            const apiKey = getNextApiKey(); // Rotate key immediately for every attempt
            localKeyAttempts++;

            try {
                console.log(`[Gemini] Attempt: ${model} | Key: ...${apiKey.substr(-4)}`);

                const url = API_URL_TEMPLATE.replace('{MODEL}', model) + apiKey;
                const payload = {
                    contents: [{
                        parts: [
                            { text: "Describe this image in detail." },
                            { inlineData: { mimeType: mimeType, data: base64 } }
                        ]
                    }],
                    systemInstruction: { parts: [{ text: systemPrompt }] }
                };

                const response = await fetch(url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });

                if (!response.ok) {
                    const status = response.status;
                    const errText = await response.text();
                    console.error(`[Gemini] Error ${status} (${model}):`, errText);

                    // If Quota/Auth issue (429, 403, 400 key invalid), try NEXT KEY (continue inner loop)
                    if (status === 429 || status === 403 || (status === 400 && errText.includes('API key'))) {
                        console.warn(`[Gemini] Key issue (${status}). Rotating key...`);
                        lastError = new Error(`Key Error ${status}: ${errText}`);
                        continue; // Go to next iteration of while loop (next key)
                    }

                    // For other errors (404 Model Not Found, 500 Server), break inner loop to switch MODEL
                    // 2.5 models might return 404 if not available
                    throw new Error(`HTTP ${status}: ${errText}`);
                }

                // Success!
                const data = await response.json();
                console.log(`[Gemini] Success:`, data);

                const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
                if (text) return text.trim();
                else throw new Error("Model returned empty text");

            } catch (e) {
                console.warn(`[Gemini] Failed attempt:`, e);
                lastError = e;

                // If it was a key rotation handled above, we continued. 
                // If we are here, it's a model/network error.
                // Break inner loop to try next MODEL.
                break;
            }
        }
    }

    throw new Error(lastError ? lastError.message : "All models/keys failed.");
}

async function generateMagicPrompt() {
    const input = els.magicInput.value.trim();
    if (!input) return showToast("Please enter an idea first", 'error');

    if (apiKeys.length === 0) {
        showToast("Please configure API Keys first!", 'error');
        return;
    }

    const originalText = els.magicGenerateButton.innerHTML;
    els.magicGenerateButton.textContent = 'Thinking...';
    els.magicGenerateButton.disabled = true;

    const style = els.magicStyleSelect.value;
    const count = parseInt(els.magicCountInput.value) || 1;

    // Prompt engineering for structured output
    const sysPrompt = `You are an Accessibilty and Image Prompt Expert.
    Action: Convert the user's idea into ${count} distinct, highly detailed, high-quality image generation prompts.
    Style: ${style ? style : 'Photorealistic/General'}.
    Constraint: Return ONLY a raw JSON array of strings. Example: ["prompt 1", "prompt 2"]. Do not use markdown code blocks.`;

    try {
        const apiKey = getNextApiKey();
        const url = API_URL_TEMPLATE.replace('{MODEL}', MODELS.PRIMARY) + apiKey;

        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{ parts: [{ text: input }] }],
                systemInstruction: { parts: [{ text: sysPrompt }] }
            })
        });

        const data = await response.json();
        let resultText = data.candidates?.[0]?.content?.parts?.[0]?.text;

        if (resultText) {
            // Clean up potentially markdown formatted JSON
            resultText = resultText.replace(/```json/g, '').replace(/```/g, '').trim();

            let prompts = [];
            try {
                prompts = JSON.parse(resultText);
            } catch (jsonError) {
                console.warn("JSON Parse failed, treating as text split", jsonError);
                // Fallback attempt to split by newlines if JSON fails
                prompts = resultText.split('\n').filter(p => p.length > 10);
            }

            if (Array.isArray(prompts) && prompts.length > 0) {
                currentMagicPrompts = prompts; // Save to state
                renderMagicResults(prompts);
                els.magicDownloadButton.disabled = false;
                els.magicDownloadButton.classList.add('btn-highlight-infinite');
                showToast(`Generated ${prompts.length} prompts!`, 'success');
            } else {
                throw new Error("Failed to parse AI response");
            }
        } else {
            throw new Error("Empty response from AI");
        }

    } catch (e) {
        console.error(e);
        showToast("Magic generation failed: " + e.message, 'error');
    } finally {
        els.magicGenerateButton.innerHTML = originalText;
        els.magicGenerateButton.disabled = false;
    }
}

function renderMagicResults(prompts) {
    els.magicResultsList.innerHTML = '';

    prompts.forEach((promptText, index) => {
        const card = document.createElement('div');
        card.className = "bg-white border border-slate-200 rounded-lg p-3 shadow-sm mb-3";

        card.innerHTML = `
            <div class="flex justify-between items-center mb-2">
                <span class="text-xs font-bold text-brand-600">Option ${index + 1}</span>
                <button class="copy-magic-btn btn btn-sm btn-secondary py-1 px-2" style="font-size: 0.75rem;">
                   <svg class="icon" style="width:12px;height:12px;margin-right:4px;" viewBox="0 0 24 24"><path d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"></path></svg>
                   Copy
                </button>
            </div>
            <textarea readonly class="result-textarea" style="height: 100px;">${promptText}</textarea>
        `;

        // Bind copy event
        const copyBtn = card.querySelector('.copy-magic-btn');
        const textarea = card.querySelector('textarea');

        copyBtn.addEventListener('click', () => {
            copyToClipboard(textarea.value);
            const originalHTML = copyBtn.innerHTML;
            copyBtn.textContent = 'Copied!';
            copyBtn.classList.add('text-green-600');
            setTimeout(() => {
                copyBtn.classList.remove('text-green-600');
                copyBtn.innerHTML = originalHTML;
            }, 1500);
        });

        els.magicResultsList.appendChild(card);
    });
}

function downloadMagicPrompts() {
    if (currentMagicPrompts.length === 0) return;

    const content = currentMagicPrompts.join('\n\n');
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `magic_prompts_${Date.now()}.txt`;
    a.click();
    showToast('Prompts downloaded!', 'success');
}



// ============================================================================
// UI RENDERING HELPERS
// ============================================================================

function createResultCard(item) {
    const div = document.createElement('div');
    div.id = `card-${item.id}`;
    div.className = "bg-white border border-slate-200 rounded-lg p-3 flex flex-col gap-2 shadow-sm result-card";

    // Preview URL
    let src = '';
    if (item.type === 'url') src = item.url;
    else src = URL.createObjectURL(item.data);

    div.innerHTML = `
        <div class="flex gap-3">
            <div class="w-16 h-16 flex-none bg-slate-100 rounded overflow-hidden">
                <img src="${src}" class="w-full h-full object-cover">
            </div>
            <div class="flex-1 min-w-0">
                <h4 class="text-xs font-bold text-slate-700 truncate mb-1">${item.name}</h4>
                <div class="status-area text-xs text-slate-500 font-mono">Waiting...</div>
            </div>
        </div>
        <div class="prompt-area hidden mt-2">
            <textarea readonly class="result-textarea"></textarea>
            <div class="flex justify-end mt-1">
                <button class="copy-btn btn btn-sm btn-link" style="font-size: 0.75rem;">Copy Prompt</button>
            </div>
        </div>
    `;

    // Copy logic
    div.querySelector('.copy-btn').addEventListener('click', function () {
        const text = div.querySelector('textarea').value;
        copyToClipboard(text);
        this.textContent = "Copied!";
        setTimeout(() => this.textContent = "Copy Prompt", 1500);
    });

    return div;
}

function updateCardStatus(card, text, colorClass) {
    const statusEl = card.querySelector('.status-area');
    statusEl.className = `status-area text-xs font-medium ${colorClass}`;
    statusEl.textContent = text;
}

function updateCardSuccess(card, promptText) {
    updateCardStatus(card, 'Generated successfully', 'text-green-600');
    const promptArea = card.querySelector('.prompt-area');
    promptArea.classList.remove('hidden');
    promptArea.querySelector('textarea').value = promptText;
}

function updateCardError(card, errorMsg) {
    updateCardStatus(card, 'Failed: ' + errorMsg, 'text-red-500');
}

// ============================================================================
// DATA & UTILS
// ============================================================================

function loadApiKeys() {
    chrome.storage.sync.get(['geminiApiKeys'], (result) => {
        apiKeys = result.geminiApiKeys || [];
        renderApiKeysList();
    });
}

async function addApiKey() {
    const rawInput = els.newApiKeyInput.value.trim();
    if (!rawInput) return showToast("Please enter at least one API key.", 'error');

    const candidates = rawInput.split(/[\n,]+/).map(k => k.trim()).filter(k => k.length > 10);
    if (candidates.length === 0) return showToast("No valid-looking keys found.", 'error');

    const statusEl = document.getElementById('testStatus');
    statusEl.classList.remove('hidden');
    statusEl.innerHTML = '<div class="text-brand-600">Starting validation...</div>';

    els.addApiKeyButton.disabled = true;
    let addedCount = 0;

    for (let i = 0; i < candidates.length; i++) {
        const key = candidates[i];

        // Skip duplicates immediately
        if (apiKeys.includes(key)) {
            statusEl.innerHTML += `<div class="text-slate-500">Key ...${key.substr(-4)}: Skipped (Duplicate)</div>`;
            continue;
        }

        statusEl.innerHTML += `<div>Testing Key ...${key.substr(-4)}...</div>`;

        try {
            // Validate Key with a lightweight call
            const isValid = await testGeminiKey(key);

            if (isValid) {
                apiKeys.push(key);
                // Save immediately one by one as requested
                await chrome.storage.sync.set({ geminiApiKeys: apiKeys });

                statusEl.lastElementChild.innerHTML = `Key ...${key.substr(-4)}: <span class="text-green-600 font-bold">Valid & Saved</span>`;
                addedCount++;
                renderApiKeysList();
            } else {
                statusEl.lastElementChild.innerHTML = `Key ...${key.substr(-4)}: <span class="text-red-500 font-bold">Invalid</span>`;
            }
        } catch (e) {
            console.error(e);
            statusEl.lastElementChild.innerHTML = `Key ...${key.substr(-4)}: <span class="text-red-500 font-bold">Error</span>`;
        }
    }

    els.addApiKeyButton.disabled = false;
    els.newApiKeyInput.value = '';

    if (addedCount > 0) {
        showToast(`Saved ${addedCount} new keys!`, 'success');
        statusEl.innerHTML += `<div class="mt-2 font-bold text-green-600">Done! Added ${addedCount} valid keys.</div>`;
    } else {
        showToast('No new valid keys added.', 'error');
        statusEl.innerHTML += `<div class="mt-2 font-bold text-red-600">No new valid keys added.</div>`;
    }
}

async function testGeminiKey(key) {
    try {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${key}`;
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{ parts: [{ text: "Hi" }] }]
            })
        });
        return response.ok;
    } catch {
        return false;
    }
}

function deleteApiKey(index) {
    if (confirm("Delete this API key?")) {
        apiKeys.splice(index, 1);
        chrome.storage.sync.set({ geminiApiKeys: apiKeys });
        renderApiKeysList();
    }
}

function getNextApiKey() {
    if (apiKeys.length === 0) return null;
    const key = apiKeys[keyIndex];
    keyIndex = (keyIndex + 1) % apiKeys.length;
    return key;
}

function downloadAllPrompts() {
    const validItems = fileQueue.filter(i => i.status === 'completed' && i.prompt);
    if (validItems.length === 0) return;

    const content = validItems.map(i => i.prompt).join('\n\n');
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gemini_prompts_${Date.now()}.txt`;
    a.click();
}

// Utils
function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result.split(',')[1]);
        reader.onerror = error => reject(error);
    });
}

async function urlToBase64(url) {
    // Send to background to avoid CORS
    const response = await chrome.runtime.sendMessage({
        action: 'fetchImage',
        url: url
    });

    if (response.success) return response.base64;
    throw new Error(response.error || 'Fetch failed');
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text);
    showToast('Copied to clipboard!', 'success');
}

function delay(ms) {
    return new Promise(r => setTimeout(r, ms));
}

function showToast(message, type = 'info') {
    if (!els.toastContainer) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    let iconSvg = '';
    if (type === 'success') {
        iconSvg = '<svg class="icon icon-success" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"></path></svg>';
    } else if (type === 'error') {
        iconSvg = '<svg class="icon icon-danger" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12"></path></svg>';
    } else {
        iconSvg = '<svg class="icon" style="stroke: var(--primary);" viewBox="0 0 24 24"><path d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>';
    }

    toast.innerHTML = `${iconSvg}<span>${message}</span>`;
    els.toastContainer.appendChild(toast);

    // Auto remove
    setTimeout(() => {
        toast.style.animation = 'fadeOutDown 0.3s forwards';
        toast.addEventListener('animationend', () => {
            toast.remove();
        });
    }, 3000);
}

// ============================================================================
// UPDATE SYSTEM
// ============================================================================

async function checkForUpdates() {
    const UPDATE_URL = 'https://euphonious-hummingbird-9ef8a8.netlify.app/version.json';
    try {
        const currentVersion = chrome.runtime.getManifest().version;

        // Populate Settings "Current Version"
        if (els.settingsCurrentVersion) els.settingsCurrentVersion.textContent = `v${currentVersion}`;
        if (els.settingsUpdateStatus) els.settingsUpdateStatus.textContent = "Checking...";

        const response = await fetch(UPDATE_URL);
        if (!response.ok) {
            if (els.settingsUpdateStatus) els.settingsUpdateStatus.textContent = "Check failed";
            return;
        }

        const data = await response.json();
        const latestVersion = data.version;

        if (compareVersions(latestVersion, currentVersion) > 0) {
            // Update available - Banner
            if (els.updateContainer && els.updateNotes && els.updateDownloadLink) {
                els.updateNotes.textContent = `v${latestVersion}: ${data.notes || 'New features available.'}`;
                els.updateDownloadLink.href = data.zip_url;
                els.updateContainer.classList.remove('hidden');
            }

            // Update available - Settings Section
            if (els.settingsUpdateStatus) {
                els.settingsUpdateStatus.textContent = `New: v${latestVersion}`;
                els.settingsUpdateStatus.classList.add('text-brand-600', 'font-bold');
            }
            if (els.settingsUpdateAction && els.settingsUpdateNotes && els.settingsDownloadLink) {
                els.settingsUpdateNotes.textContent = `v${latestVersion} Change Log: ${data.notes}`;
                els.settingsDownloadLink.href = data.zip_url;
                els.settingsUpdateAction.classList.remove('hidden');
            }
        } else {
            // No update
            if (els.settingsUpdateStatus) {
                els.settingsUpdateStatus.textContent = "Up to date";
                els.settingsUpdateStatus.classList.add('text-green-600');
            }
        }
    } catch (e) {
        console.warn('Update check failed:', e);
        if (els.settingsUpdateStatus) els.settingsUpdateStatus.textContent = "Offline/Error";
    }
}

function compareVersions(v1, v2) {
    const p1 = v1.split('.').map(Number);
    const p2 = v2.split('.').map(Number);
    const k = Math.max(p1.length, p2.length);
    for (let i = 0; i < k; i++) {
        if ((p1[i] || 0) > (p2[i] || 0)) return 1;
        if ((p1[i] || 0) < (p2[i] || 0)) return -1;
    }
    return 0;
}

// ============================================================================
// TRENDS SYSTEM FIX (SIMPLE LINK)
// ============================================================================
document.addEventListener('DOMContentLoaded', () => {
    const trendsBtn = document.getElementById('trendsTabButton');
    if (trendsBtn) {
        // Clone and replace to strip existing event listeners (e.g. broken switchTab)
        const newBtn = trendsBtn.cloneNode(true);
        trendsBtn.parentNode.replaceChild(newBtn, trendsBtn);

        newBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            window.open('https://www.shutterstock.com/id/trends', '_blank');
        });

        console.log('Trends button logic updated to simple link.');
    }
});

// ============================================================================

// ============================================================================
// TRENDS SYSTEM
// ============================================================================

// Get DOM elements for trends
const trendsElements = {
    loading: document.getElementById('trendsLoading'),
    list: document.getElementById('trendsList')
};

// Fetch trends from background
async function fetchTrends() {
    if (!trendsElements.loading || !trendsElements.list) {
        console.error('Trends elements not found');
        return;
    }

    // Show loading
    trendsElements.loading.classList.remove('hidden');
    trendsElements.list.innerHTML = '';

    try {
        const response = await chrome.runtime.sendMessage({
            action: 'scrapeTrends'
        });

        if (response && response.success && response.data) {
            displayTrends(response.data);
        } else {
            trendsElements.list.innerHTML = `<p class="empty-message" style="color: var(--danger);">Gagal memuat trends: ${response?.error || 'Unknown error'}</p>`;
        }
    } catch (error) {
        console.error('Trend fetch failed:', error);
        trendsElements.list.innerHTML = `<p class="empty-message" style="color: var(--danger);">Error: ${error.message}</p>`;
    } finally {
        trendsElements.loading.classList.add('hidden');
    }
}

// Helper functions for scoring
function parseCompetition(text) {
    if (!text || text === 'N/A') return 1;
    // Remove non-digits (e.g. "12,000 Results")
    const num = parseInt(text.replace(/[^0-9]/g, ''));
    return isNaN(num) || num === 0 ? 1 : num;
}

function parseGrowth(text) {
    if (!text || text === 'N/A') return 0;
    // Handle percentages e.g. "+120%" -> 120
    const num = parseFloat(text.replace(/[^0-9.,-]/g, '').replace(',', '.'));
    return isNaN(num) ? 0 : num;
}

function parseDemand(text) {
    if (!text || text === 'N/A') return 1;
    const t = text.toLowerCase();
    // Scoring: High=3, Medium=2, Low=1
    if (t.includes('high') || t.includes('tinggi')) return 3;
    if (t.includes('medium') || t.includes('sedang')) return 2;
    if (t.includes('low') || t.includes('rendah')) return 1;
    // Fallback if it's already a number
    const num = parseFloat(text);
    return isNaN(num) ? 1 : num;
}

function calculateOpportunityScore(demand, growth, competition) {
    // Score ~ (Demand * Growth) / Competition
    // Higher demand & growth + Lower competition = Higher Opportunity

    // Safety check just in case
    const safeComp = competition <= 0 ? 1 : competition;
    return (demand * growth) / safeComp;
}

// Display trends in the UI (sorted by Opportunity Score)
function displayTrends(trends) {
    if (!trends || trends.length === 0) {
        trendsElements.list.innerHTML = '<p class="empty-message">Tidak ada trends ditemukan.</p>';
        return;
    }

    // 1. Process and Calculate Scores
    const processedTrends = trends.map(trend => {
        const demandScore = parseDemand(trend.demand);
        const growthScore = parseGrowth(trend.growth);
        const competitionScore = parseCompetition(trend.results);

        const oppScore = calculateOpportunityScore(demandScore, growthScore, competitionScore);

        return {
            ...trend,
            _demandScore: demandScore,
            _growthScore: growthScore,
            _competitionScore: competitionScore,
            _oppScore: oppScore
        };
    });

    // 2. Sort by Opportunity Score (Descending)
    processedTrends.sort((a, b) => b._oppScore - a._oppScore);

    // 3. Render
    const sortingInfo = `
        <div style="margin-bottom: 16px; text-align: center;">
            <div style="display: inline-block; background: #f1f5f9; border: 1px solid var(--border); border-radius: 50px; padding: 6px 16px; font-size: 0.75rem; color: var(--text-muted);">
                ✨ Diurutkan berdasarkan <strong>Opportunity Score</strong> tertinggi
            </div>
        </div>
    `;

    trendsElements.list.innerHTML = sortingInfo + processedTrends.map((trend, index) => {
        // Format score for display (multiply by 1000 or similar if numbers are too small?)
        // Raw score might be useful enough. e.g. (3 * 100) / 10000 = 0.03
        // Let's keep 4 decimals
        const scoreDisplay = trend._oppScore.toFixed(5);

        return `
        <div class="result-card trend-card" style="margin-bottom: 12px; transition: all 0.2s; border: 1px solid var(--border); position: relative;" 
             data-keyword="${trend.term.replace(/"/g, '&quot;')}">
            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 8px;">
                <h4 style="margin: 0; font-size: 1rem; color: var(--text-main); font-weight: 600; cursor: pointer;">
                    <span style="color: var(--brand); font-size: 0.8em;">#${index + 1}</span> ${trend.term}
                </h4>
                <button class="btn btn-sm btn-primary use-trend-btn" style="flex-shrink: 0; margin-left: 8px;" 
                        data-keyword="${trend.term.replace(/"/g, '&quot;')}" type="button">
                    <svg class="icon icon-sm" viewBox="0 0 24 24">
                        <path d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 3.214L13 21l-2.286-6.857L5 12l5.714-3.214z"></path>
                    </svg>
                    Gunakan
                </button>
            </div>
            
            <div style="display: flex; gap: 8px; font-size: 0.75rem; color: var(--text-muted); flex-wrap: wrap; margin-bottom: 6px;">
                <div style="background: #f0fdf4; color: #15803d; padding: 2px 6px; border-radius: 4px;" title="Competition (Results Count)">
                    👥 Comp: ${trend.results}
                </div>
                <div style="background: #fffbeb; color: #b45309; padding: 2px 6px; border-radius: 4px;" title="Growth Rate">
                    📈 Growth: ${trend.growth}
                </div>
                <div style="background: #eff6ff; color: #1e40af; padding: 2px 6px; border-radius: 4px;" title="Demand Level">
                    🔥 Demand: ${trend.demand}
                </div>
            </div>

            <div style="background: #f8fafc; padding: 6px; border-radius: 4px; display: flex; align-items: center; gap: 6px;">
                 <span style="font-weight: 600; font-size: 0.8rem; color: var(--text-main);">Opportunity Score:</span>
                 <span style="font-family: monospace; font-weight: 700; color: var(--brand); font-size: 0.9rem;">${scoreDisplay}</span>
                 <span style="font-size: 0.7rem; color: #94a3b8; margin-left: auto;">(D×G)/C</span>
            </div>
        </div>
    `;
    }).join('');

    showToast(`Berhasil memuat ${trends.length} trends (Sorted by Opportunity)!`, 'success');
}

// Event delegation for trends list (set up once on init)
if (trendsElements.list) {
    trendsElements.list.addEventListener('click', function (e) {
        const button = e.target.closest('.use-trend-btn');
        const card = e.target.closest('.trend-card');

        if (button) {
            e.preventDefault();
            e.stopPropagation();
            const keyword = button.getAttribute('data-keyword');
            if (keyword) {
                useTrendKeyword(keyword);
            }
        } else if (card && !e.target.closest('button')) {
            const keyword = card.getAttribute('data-keyword');
            if (keyword) {
                useTrendKeyword(keyword);
            }
        }
    });
}

// Use trend keyword in Magic Prompt
function useTrendKeyword(keyword) {
    // Switch to Magic tab
    const magicTab = document.querySelector('[data-tab="magic"]');
    if (magicTab) {
        magicTab.click();
    }

    // Fill the magic input
    const magicInput = document.getElementById('magicInput');
    if (magicInput) {
        magicInput.value = keyword;
        magicInput.focus();

        showToast(`Keyword "${keyword}" telah dimasukkan ke Magic Prompt!`, 'success');
    }
}

// Add event listener to open trends page button
const openTrendsPageButton = document.getElementById('openTrendsPageButton');
if (openTrendsPageButton) {
    openTrendsPageButton.addEventListener('click', () => {
        window.open('https://www.shutterstock.com/id/trends', '_blank');
        showToast('Membuka halaman Shutterstock Trends...', 'info');
    });
}

// TRENDS KEYWORD RECEIVER
// ============================================================================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'fillMagicPrompt') {
        // Switch to Magic tab
        const magicTab = document.querySelector('[data-tab="magic"]');
        if (magicTab) {
            magicTab.click();
        }

        // Fill the magic input with the keyword
        const magicInput = document.getElementById('magicInput');
        if (magicInput) {
            magicInput.value = message.keyword;
            magicInput.focus();

            // Show toast notification
            showToast(`Keyword "${message.keyword}" telah dimasukkan ke Magic Prompt!`, 'success');
        }

        sendResponse({ success: true });
    }
    return true;
});

// ============================================================================
// INITIALIZATION
// ============================================================================
document.addEventListener('DOMContentLoaded', () => {
    console.log('Sidepanel initialized');

    // Check for updates
    checkForUpdates();

    // Initialize API status
    // Check if updateApiStatus exists before calling, or assume it's global
    if (typeof updateApiStatus === 'function') {
        updateApiStatus();
    }

    // Set up tab switching
    setupTabs();
});

// Tab switching functionality
function setupTabs() {
    const tabs = document.querySelectorAll('.tab-button');
    const contents = document.querySelectorAll('.tab-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetTab = tab.dataset.tab;
            if (!targetTab) return;

            // Remove active from all
            tabs.forEach(t => t.classList.remove('active'));
            contents.forEach(c => c.classList.remove('active'));

            // Add active to clicked
            tab.classList.add('active');
            const targetContent = document.getElementById(targetTab + 'Tab');
            if (targetContent) {
                targetContent.classList.add('active');
            }

            // Auto-load trends if empty
            if (targetTab === 'trends') {
                const list = document.getElementById('trendsList');
                // Check if we already have data loaded to prevent unnecessary scraping
                const hasData = list && list.querySelectorAll('.trend-card').length > 0;

                // Also check if we are already loading to avoid double fetch
                const isLoading = document.getElementById('trendsLoading')?.classList.contains('hidden') === false;

                if (!hasData && !isLoading) {
                    console.log('Auto-loading trends...');
                    fetchTrends();
                }
            }
        });
    });
}