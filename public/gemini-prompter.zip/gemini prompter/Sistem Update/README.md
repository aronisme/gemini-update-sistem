# Chrome Extension Update Server (Netlify)

Deploy this project to Netlify to serve:
- version.json (update checker)
- extension.zip (latest extension build)

## How to use
1. Upload your extension files into a zip named extension.zip
2. Update version.json
3. Deploy to Netlify
"# gemini-update-sistem" 
