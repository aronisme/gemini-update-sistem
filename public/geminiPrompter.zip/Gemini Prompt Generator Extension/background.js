// Background Service Worker for Gemini Image Prompt Generator

// Enable side panel on extension icon click
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error('Error setting panel behavior:', error));

// Create context menu on installation
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'scrapeImages',
    title: 'Scrape Images with Gemini',
    contexts: ['page', 'image']
  });
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'scrapeImages') {
    // Open side panel
    chrome.sidePanel.open({ windowId: tab.windowId });

    // Send message to trigger scraping
    setTimeout(() => {
      chrome.runtime.sendMessage({
        action: 'contextMenuScrape',
        tabId: tab.id
      });
    }, 500); // Delay to ensure panel is open
  }
});

// Handle messages from content script and side panel
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'scrapeImages') {
    // Get active tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        // Inject and execute content script
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id, allFrames: true },
          function: scrapeImagesFromPage
        }, (results) => {
          if (chrome.runtime.lastError) {
            // It's common to have some frames (like restricted ones) fail, 
            // but we might still have results from others.
            // Check if we have partial results or just fail gracefully.
            console.warn("Scraping warning:", chrome.runtime.lastError.message);
          }

          if (results && results.length > 0) {
            // Aggregate results from all frames
            const allImages = results.flatMap(frameResult => frameResult.result || []);

            // Deduplicate based on URL
            const seenUrls = new Set();
            const uniqueImages = [];

            allImages.forEach(img => {
              if (img.url && !seenUrls.has(img.url)) {
                seenUrls.add(img.url);
                uniqueImages.push(img);
              }
            });

            sendResponse({
              success: true,
              images: uniqueImages
            });
          } else {
            sendResponse({
              success: false,
              error: 'No results from scraping'
            });
          }
        });
      } else {
        sendResponse({
          success: false,
          error: 'No active tab found'
        });
      }
    });
    return true; // Keep channel open for async response
  }

  // Handle image fetching to bypass CORS
  if (message.action === 'fetchImage') {
    fetch(message.url)
      .then(response => response.blob())
      .then(blob => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64Data = reader.result.split(',')[1];
          sendResponse({ success: true, base64: base64Data });
        };
        reader.onerror = () => {
          sendResponse({ success: false, error: 'Failed to convert image to base64' });
        };
        reader.readAsDataURL(blob);
      })
      .catch(error => {
        sendResponse({ success: false, error: error.message });
      });
    return true; // Keep channel open for async response
  }

  // Handle generic page fetching (text/html)
  if (message.action === 'fetchPage') {
    fetch(message.url)
      .then(response => response.text())
      .then(text => {
        sendResponse({ success: true, content: text });
      })
      .catch(error => {
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }



  if (message.action === 'scrapeTrends') {
    // Create a hidden tab to scrape trends
    chrome.tabs.create({ url: 'https://www.shutterstock.com/id/trends', active: false }, (tab) => {
      const tabId = tab.id;

      // Listener to wait for load
      const listener = (tid, changeInfo, t) => {
        if (tid === tabId && changeInfo.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(listener);

          // Wait a bit for client-side rendering (SPA)
          setTimeout(() => {
            chrome.scripting.executeScript({
              target: { tabId: tabId },
              function: extractTrendsData
            }, (results) => {
              chrome.tabs.remove(tabId); // Cleanup

              if (chrome.runtime.lastError) {
                console.error("Script execution failed:", chrome.runtime.lastError);
                sendResponse({ success: false, error: chrome.runtime.lastError.message });
              } else if (results && results[0] && results[0].result) {
                sendResponse({ success: true, data: results[0].result });
              } else {
                sendResponse({ success: false, error: 'No data found (DOM might be different)' });
              }
            });
          }, 3000); // 3 second delay for rendering
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
    });
    return true; // Keep channel open
  }

    if (message.action === 'useKeywordFromTrends') {
    // Forward the keyword to the sidepanel
    chrome.runtime.sendMessage({
      action: 'fillMagicPrompt',
      keyword: message.keyword
    });
    sendResponse({ success: true });
    return true;
  }

  if (message.action === 'getTabId') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      sendResponse({ tabId: tabs[0]?.id });
    });
    return true;
  }
});




function extractTrendsData() {
  const trends = [];
  const seenTerms = new Set();

  // Find cells identifying rows
  const resultCells = document.querySelectorAll('[data-automation="results-cell"]');

  resultCells.forEach(cell => {
    // Traverse up to find the row container (likely an A tag)
    let row = cell.parentElement;
    let depth = 0;
    while (row && row.tagName !== 'A' && depth < 5) {
      row = row.parentElement;
      depth++;
    }

    if (row && row.tagName === 'A' && !seenTerms.has(row)) {
      const img = row.querySelector('img');
      const term = img ? img.alt : row.textContent.trim().split('\n')[0];

      if (!term || seenTerms.has(term)) return;
      seenTerms.add(term);

      // Helper to clean text
      const clean = (sel, remove) => {
        const el = row.querySelector(sel);
        if (!el) return 'N/A';
        return el.textContent.replace(remove, '').trim();
      };

      const resultsText = clean('[data-automation="results-cell"]', /Results:|Hasil:/i);
      const growthText = clean('[data-automation="growth-cell"]', /Growth:|Pertumbuhan:/i);
      const demandText = clean('[data-automation="demand-cell"]', /Demand:|Permintaan:/i);

      if (term && term.length > 1) {
        trends.push({
          term: term,
          results: resultsText,
          demand: demandText,
          growth: growthText
        });
      }
    }
  });

  return trends;
}

// Function to be injected into page context
function scrapeImagesFromPage() {
  const images = [];
  const seenUrls = new Set();
  const MIN_WIDTH = 100;
  const MIN_HEIGHT = 100;

  // Helper to normalize URLs
  function normalizeUrl(url) {
    try {
      return new URL(url, window.location.href).href;
    } catch {
      return null;
    }
  }

  // Helper to check if image meets size requirements
  function meetsMinimumSize(width, height) {
    return width >= MIN_WIDTH && height >= MIN_HEIGHT;
  }

  // 1. Scrape from <img> tags
  const imgElements = document.querySelectorAll('img');
  imgElements.forEach(img => {
    const src = img.src || img.dataset.src || img.dataset.lazySrc;
    if (!src) return;

    const normalizedUrl = normalizeUrl(src);
    if (!normalizedUrl || seenUrls.has(normalizedUrl)) return;

    const width = img.naturalWidth || img.width;
    const height = img.naturalHeight || img.height;

    if (meetsMinimumSize(width, height)) {
      seenUrls.add(normalizedUrl);
      images.push({
        url: normalizedUrl,
        alt: img.alt || '',
        width: width,
        height: height,
        type: 'img'
      });
    }
  });

  // 2. Scrape from CSS background images
  const allElements = document.querySelectorAll('*');
  allElements.forEach(element => {
    const style = window.getComputedStyle(element);
    const bgImage = style.backgroundImage;

    if (bgImage && bgImage !== 'none') {
      const urlMatch = bgImage.match(/url\(['"]?([^'"]+)['"]?\)/);
      if (urlMatch && urlMatch[1]) {
        const normalizedUrl = normalizeUrl(urlMatch[1]);
        if (normalizedUrl && !seenUrls.has(normalizedUrl)) {
          // For background images, we can't easily get dimensions without loading
          // So we'll include them and let the side panel filter if needed
          const rect = element.getBoundingClientRect();
          if (rect.width >= MIN_WIDTH && rect.height >= MIN_HEIGHT) {
            seenUrls.add(normalizedUrl);
            images.push({
              url: normalizedUrl,
              alt: element.getAttribute('aria-label') || '',
              width: Math.round(rect.width),
              height: Math.round(rect.height),
              type: 'background'
            });
          }
        }
      }
    }
  });

  // 3. Scrape from picture/source elements
  const pictureElements = document.querySelectorAll('picture source');
  pictureElements.forEach(source => {
    const srcset = source.srcset;
    if (srcset) {
      const urls = srcset.split(',').map(s => s.trim().split(' ')[0]);
      urls.forEach(url => {
        const normalizedUrl = normalizeUrl(url);
        if (normalizedUrl && !seenUrls.has(normalizedUrl)) {
          seenUrls.add(normalizedUrl);
          images.push({
            url: normalizedUrl,
            alt: '',
            width: 0,
            height: 0,
            type: 'picture'
          });
        }
      });
    }
  });

  return images;
}
