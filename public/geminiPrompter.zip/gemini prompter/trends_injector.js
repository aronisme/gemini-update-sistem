// Content script for injecting "Use Keyword" buttons on Shutterstock Trends page
// Only runs on https://www.shutterstock.com/id/trends

(function () {
    'use strict';

    // Only run on trends page
    if (!window.location.href.includes('shutterstock.com') || !window.location.href.includes('trends')) {
        return;
    }

    console.log('Trends Injector: Script loaded');

    // CSS for the inject button
    const style = document.createElement('style');
    style.textContent = `
        .gemini-use-keyword-btn {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 6px 12px;
            background: linear-gradient(135deg, #4F46E5, #7C3AED);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 2px 4px rgba(79, 70, 229, 0.3);
            margin-left: 8px;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }

        .gemini-use-keyword-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(79, 70, 229, 0.4);
        }

        .gemini-use-keyword-btn:active {
            transform: translateY(0);
        }

        .gemini-use-keyword-btn svg {
            width: 14px;
            height: 14px;
            fill: none;
            stroke: currentColor;
            stroke-width: 2;
            stroke-linecap: round;
            stroke-linejoin: round;
        }

        .gemini-keyword-copied {
            background: #10b981 !important;
        }
    `;
    document.head.appendChild(style);

    // Function to inject buttons
    function injectButtons() {
        // Find all trend items - adjust selector based on actual DOM structure
        // Looking for cells with data-automation="results-cell" as indicators
        const resultCells = document.querySelectorAll('[data-automation="results-cell"]');

        let injectedCount = 0;

        resultCells.forEach(cell => {
            // Find the parent row (usually an A tag)
            let row = cell.parentElement;
            let depth = 0;
            while (row && row.tagName !== 'A' && depth < 5) {
                row = row.parentElement;
                depth++;
            }

            if (!row) return;

            // Check if button already exists
            if (row.querySelector('.gemini-use-keyword-btn')) return;

            // Get the keyword from the img alt or text content
            const img = row.querySelector('img');
            const keyword = img ? img.alt : row.textContent.trim().split('\n')[0].trim();

            if (!keyword || keyword.length < 2) return;

            // Create button
            const button = document.createElement('button');
            button.className = 'gemini-use-keyword-btn';
            button.innerHTML = `
                <svg viewBox="0 0 24 24">
                    <path d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 3.214L13 21l-2.286-6.857L5 12l5.714-3.214z"></path>
                </svg>
                <span>Gunakan</span>
            `;

            button.title = `Gunakan keyword: ${keyword}`;

            // Add click handler
            button.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();

                // Send message to background script
                chrome.runtime.sendMessage({
                    action: 'useKeywordFromTrends',
                    keyword: keyword
                }, (response) => {
                    if (response && response.success) {
                        // Visual feedback
                        const originalHTML = button.innerHTML;
                        button.classList.add('gemini-keyword-copied');
                        button.innerHTML = `
                            <svg viewBox="0 0 24 24">
                                <path d="M5 13l4 4L19 7"></path>
                            </svg>
                            <span>Berhasil!</span>
                        `;

                        setTimeout(() => {
                            button.classList.remove('gemini-keyword-copied');
                            button.innerHTML = originalHTML;
                        }, 2000);
                    }
                });
            });

            // Find a good place to insert the button
            // Try to insert near the keyword text
            const textContainer = row.querySelector('h4, h3, h2, h5, [class*="title"], [class*="text"]');
            if (textContainer) {
                textContainer.style.display = 'flex';
                textContainer.style.alignItems = 'center';
                textContainer.appendChild(button);
            } else {
                // Fallback: add to the row
                row.style.position = 'relative';
                const wrapper = document.createElement('div');
                wrapper.style.cssText = 'position: absolute; top: 8px; right: 8px; z-index: 10;';
                wrapper.appendChild(button);
                row.appendChild(wrapper);
            }

            injectedCount++;
        });

        if (injectedCount > 0) {
            console.log(`Trends Injector: Injected ${injectedCount} buttons`);
        }
    }

    // Initial injection after a delay (wait for dynamic content)
    setTimeout(injectButtons, 2000);

    // Re-inject on scroll (for lazy loading)
    let scrollTimeout;
    window.addEventListener('scroll', () => {
        clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(injectButtons, 500);
    });

    // Observe DOM changes
    const observer = new MutationObserver((mutations) => {
        let shouldInject = false;
        mutations.forEach(mutation => {
            if (mutation.addedNodes.length > 0) {
                shouldInject = true;
            }
        });
        if (shouldInject) {
            setTimeout(injectButtons, 300);
        }
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    console.log('Trends Injector: Observers set up');
})();
