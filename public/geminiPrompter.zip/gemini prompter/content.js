// Content Script for Gemini Image Prompt Generator
// This script runs in the context of web pages

// Listen for messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'ping') {
        sendResponse({ status: 'ready' });
    }
});

// Optional: Observer for dynamically loaded images (lazy loading)
const imageObserver = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
            if (node.nodeName === 'IMG') {
                // Could send updates to side panel about new images
                console.log('New image detected:', node.src);
            }
        });
    });
});

// Start observing the document with the configured parameters
imageObserver.observe(document.body, {
    childList: true,
    subtree: true
});
