# Debugging Guide - API Key Issue

## Problem
User tidak bisa menambahkan API key ke extension.

## Debugging Steps

### 1. Reload Extension
1. Buka `chrome://extensions/`
2. Klik tombol **Reload** (🔄) di card extension "Gemini Image Prompt Generator"
3. Buka side panel lagi dengan klik icon extension

### 2. Check Console Logs
1. Klik kanan di dalam side panel
2. Pilih **Inspect** atau **Inspect Element**
3. Buka tab **Console**
4. Coba tambah API key lagi
5. Lihat pesan di console:
   - Seharusnya ada log: `"Add API Key button clicked"`
   - Lalu: `"Adding API key, length: XX"`
   - Lalu: `"API key added, total keys: 1"`
   - Lalu: `"API keys saved successfully: 1"`

### 3. Check for Errors
Di console, cari error messages berwarna merah:
- Error tentang `chrome.storage`?
- Error tentang `elements.newApiKeyInput is null`?
- Error lainnya?

### 4. Test API Key Length
API key Gemini biasanya panjangnya 39 karakter dan dimulai dengan `AIza...`

Contoh format: `AIzaSyDxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

Jika key yang Anda masukkan **kurang dari 30 karakter**, akan muncul error "API Key seems too short".

### 5. Check Storage Permission
1. Buka `chrome://extensions/`
2. Cari extension "Gemini Image Prompt Generator"
3. Klik **Details**
4. Scroll ke bawah, pastikan permission `storage` ada
5. Jika tidak ada, reload extension

### 6. Manual Test di Console
Paste kode ini di Console DevTools side panel:

```javascript
// Test 1: Check if elements exist
console.log('Input element:', document.getElementById('newApiKeyInput'));
console.log('Button element:', document.getElementById('addApiKeyButton'));

// Test 2: Try to add a test key manually
chrome.storage.sync.set({ geminiApiKeys: ['test_key_12345678901234567890123456789012'] }, () => {
    console.log('Manual test key saved');
    chrome.storage.sync.get(['geminiApiKeys'], (result) => {
        console.log('Stored keys:', result.geminiApiKeys);
    });
});
```

### 7. Try Alternative: Use localStorage Temporarily
Jika chrome.storage bermasalah, bisa gunakan localStorage sebagai fallback sementara.

Edit `sidepanel.js`, ganti fungsi `loadApiKeys()` dan `saveApiKeys()`:

```javascript
// TEMPORARY FIX - Replace chrome.storage with localStorage
async function loadApiKeys() {
    try {
        const stored = localStorage.getItem('geminiApiKeys');
        apiKeys = stored ? JSON.parse(stored) : [];
        console.log('API keys loaded from localStorage:', apiKeys.length);
        renderApiKeys();
    } catch (error) {
        console.error('Error loading API keys:', error);
        apiKeys = [];
        renderApiKeys();
    }
}

async function saveApiKeys() {
    try {
        localStorage.setItem('geminiApiKeys', JSON.stringify(apiKeys));
        console.log('API keys saved to localStorage:', apiKeys.length);
        renderApiKeys();
    } catch (error) {
        console.error('Error saving API keys:', error);
        showAlert('Error saving API keys: ' + error.message, 'error');
    }
}
```

## Expected Console Output (Normal)
```
Side panel loaded
Elements check: {newApiKeyInput: true, addApiKeyButton: true, apiKeyListContainer: true}
API keys loaded: 0
Window fully loaded
[User clicks Add button]
Add API Key button clicked
Adding API key, length: 39
API key added, total keys: 1
API keys saved successfully: 1
```

## Common Issues

### Issue 1: "API Key seems too short"
**Cause**: Key kurang dari 30 karakter
**Solution**: Pastikan API key lengkap, biasanya 39 karakter

### Issue 2: Button tidak merespon
**Cause**: JavaScript error atau element tidak terload
**Solution**: Reload extension, check console untuk errors

### Issue 3: Storage permission denied
**Cause**: Manifest.json tidak benar atau extension tidak reload
**Solution**: Reload extension di chrome://extensions/

### Issue 4: Key hilang setelah reload
**Cause**: chrome.storage.sync gagal
**Solution**: Gunakan localStorage fix di atas

## Report Back
Setelah coba steps di atas, beritahu:
1. Apa yang muncul di console?
2. Apakah ada error message?
3. Screenshot console log jika memungkinkan
