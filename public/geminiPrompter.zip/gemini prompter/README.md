# Gemini Image Prompt Generator - Chrome Extension

A powerful Chrome extension that scrapes images from web pages and generates detailed AI prompts using Google's Gemini Vision API.

**Created by: Aron Muhammad**

## ✨ Features

### 🖼️ Image Scraping
- Scrape images from any website with one click
- Extracts from `<img>` tags, CSS backgrounds, and `<picture>` elements
- Automatic filtering (minimum 100x100px)
- Visual selection with thumbnails
- Select/deselect individual images or use bulk actions
- Mix scraped and uploaded images in one queue

### 🎨 AI Prompt Generation
- Generate detailed, artistic prompts optimized for image generation models
- Multiple artistic styles:
  - Cinematic, Anime, Oil Painting, Watercolor
  - 3D Render, Minimalist, Cyberpunk, Pixel Art
  - Product Photography, Portrait, Cutout/Isolated, and more
- Original Style option that matches source image
- Smart English output optimized for Imagen/Midjourney/DALL-E
- Batch processing with progress tracking
- Failed generation retry system

### ✨ Magic Prompt
- Turn short ideas into detailed creative prompts
- Selectable art styles (Cinematic, Anime, 3D, etc.)
- Customizable quantity (1-10 prompts at once)
- Perfect for brainstorming and creative exploration
- Download prompts as .txt file

### 📈 Shutterstock Trends
- Quick access to Shutterstock trending searches
- Opens Shutterstock Trends page in new tab
- Stay updated with current creative trends

### 🔑 Smart API Key Management
- **Bulk Input**: Add multiple keys at once (one per line)
- **Auto-Validation**: Keys are tested before saving
- **Key Rotation**: Automatic rotation to distribute API load
- **Active Status Counter**: View total number of working keys
- **Remove Individual Keys**: Delete specific keys easily
- **Download Trends Page**: Save Shutterstock trends HTML for offline analysis
- Persistent storage across browser sessions

### 📁 File Upload Support
- Upload local images (JPEG, PNG, WebP)
- Multi-file selection
- Mix scraped and uploaded images
- Drag-and-drop support

## 🚀 Installation

### Step 1: Get a Gemini API Key

1. Visit [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Sign in with your Google account
3. Click "Create API Key"
4. Copy the generated key
5. **Recommended**: Create 3-5 API keys for better reliability

### Step 2: Load the Extension

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode" (toggle in top-right corner)
3. Click "Load unpacked"
4. Select the `gemini prompter` folder
5. The extension should now appear in your extensions list

### Step 3: Pin the Extension (Optional)

1. Click the puzzle icon (Extensions) in Chrome toolbar
2. Find "Gemini Image Prompt Generator"
3. Click the pin icon to keep it visible

## 📖 Usage

### Opening the Side Panel

You can open the side panel in three ways:

1. **Click the extension icon** in the Chrome toolbar
2. **Right-click on any page** → Select "Scrape Images with Gemini"
3. **Keyboard shortcut**: `Ctrl+Shift+P` (Windows/Linux) or `Cmd+Shift+P` (Mac)

### Configuring API Keys

1. Open the side panel and go to the **Settings** tab
2. Paste one or more API Keys into the text area (one per line)
3. Click **"Test & Save Valid Keys"**
4. The system will validate each key individually
5. Only valid keys will be saved
6. View the count of active keys at the top of the list

**Tip**: Adding multiple API keys improves reliability and helps avoid rate limits!

### Scraping Images from a Page

1. Navigate to any website with images
2. Open the side panel (**Main Tab**)
3. Click **"Scrape Current Page"**
4. Wait for images to load (toast notification when done)
5. Select the images you want to process:
   - Click on individual images to select/deselect (checkmark appears)
   - Use "Select All" / "Deselect All" for bulk selection
6. Selected images are automatically added to the processing queue

### Uploading Local Images

1. In the side panel, scroll to **"📁 Upload Local Files"**
2. Click **"Choose Files"**
3. Select one or more images from your computer
4. Images will be added to the queue automatically

### Generating Prompts

1. **(Optional)** Choose a global style from the dropdown
   - Select "Original Style" to match source image aesthetic
   - Or choose a specific style (Cinematic, Anime, etc.)
2. Ensure at least one API key is configured
3. Click **"Start Generation"**
4. Wait for the AI to process each image
5. View generated prompts in the results section
6. Failed images will be automatically retried once

### Using Magic Prompt

1. Go to the **Magic Prompt** tab
2. Enter a short idea (e.g., "a cat in space", "futuristic city")
3. Select a style from the dropdown
4. Set quantity (1-10 prompts)
5. Click **"Generate Magic Prompts"**
6. Copy individual prompts or download all as .txt file

### Accessing Trending Topics

1. Click the **Trends** tab button
2. Opens Shutterstock Trends page in a new browser tab
3. Explore current trending creative searches and concepts

### Downloading Results

**Main Tab Prompts:**
1. After generating prompts, click **"Download Prompts (.txt)"**
2. A text file will be downloaded with all successful prompts
3. Format: One prompt per image with separators

**Magic Prompts:**
1. Click **"Download Magic Prompts"** button
2. Downloads all generated magic prompts to a .txt file

**Settings - Trends Page:**
1. In Settings tab, click **"Download Shutterstock Trends"**
2. Downloads the Shutterstock trends page HTML for offline viewing

## 📁 File Structure

```
gemini prompter/
├── manifest.json          # Extension configuration
├── background.js          # Service worker for side panel management
├── content.js             # Content script for image scraping
├── sidepanel.html         # Side panel UI
├── sidepanel.css          # Side panel styles
├── sidepanel.js           # Side panel logic
├── icons/                 # Extension icons
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md              # This file
```

## 🔧 Troubleshooting

### Extension won't load
- Make sure you selected the correct folder (containing `manifest.json`)
- Check the console in `chrome://extensions/` for error messages
- Verify all required files are present
- Try clicking the "Reload" button on the extension card

### Images not scraping
- Some websites may block scraping due to CORS policies
- Try refreshing the page before scraping
- Check browser console for errors (F12 → Console tab)
- Ensure the page has fully loaded before scraping

### API errors
- Verify your API key is valid at [Google AI Studio](https://makersuite.google.com/)
- Check your API quota and usage limits
- Add multiple API keys for better reliability
- If you get rate limit errors, wait a few seconds and try again
- The extension will automatically rotate through available keys

### Generation failures
- Failed images will be automatically retried once
- Check that your API key hasn't expired
- Verify the image is accessible (some CORS-protected images may fail)
- Try uploading the image locally instead

### Side panel not opening
- Try clicking the extension icon again
- Use the keyboard shortcut: `Ctrl+Shift+P` (or `Cmd+Shift+P` on Mac)
- Reload the extension from `chrome://extensions/`
- Check if another extension is using the same shortcut

### Images showing as broken
- Some images may have CORS restrictions
- Try uploading the image locally instead
- The prompt generation may still work even if preview fails

### Magic Prompt not generating
- Ensure at least one valid API key is configured
- Check that you've entered text in the input field
- Try a different style if one fails
- Check browser console for detailed error messages

## ⚙️ Technical Details

### Permissions
- `sidePanel` - For side panel functionality
- `storage` - For saving API keys and preferences
- `activeTab` - For accessing current page
- `scripting` - For injecting image scraper
- `contextMenus` - For right-click menu
- `<all_urls>` - For scraping images from any website

### AI Models (Gemini 2.5)
- Primary: `gemini-2.5-flash` (Fast, reliable)
- Fallback: `gemini-2.5-flash-lite` (Lightweight)
- Auto-rotation through multiple API keys
- Smart retry logic with exponential backoff

### Processing Limits
- **Session Limit**: 25 images maximum per generation
- **Request Delay**: 2 seconds between API calls
- **Retry Attempts**: 1 automatic retry for failed generations
- **Supported Formats**: JPEG, PNG, WebP
- **Minimum Image Size**: 100x100 pixels

### Storage
- API keys: Chrome sync storage (encrypted)
- Preferences: Local storage
- Temporary data: Session storage only

## 🔒 Privacy & Security

- API keys are stored locally using Chrome's secure storage
- No data is sent to third parties except Google's Gemini API
- Images are processed locally and only sent to Gemini for analysis
- Scraped images are not saved permanently
- No tracking or analytics
- All processing happens client-side

## 💡 Tips & Best Practices

1. **Use Multiple API Keys**: Add 3-5 keys for better reliability and to avoid rate limits
2. **Select Relevant Images**: Not all images make good prompts - choose clear, interesting subjects
3. **Experiment with Styles**: Different styles can dramatically change prompt output
4. **Original Style**: Use this when you want prompts that match the source aesthetic
5. **Magic Prompt**: Great for brainstorming and exploring variations of an idea
6. **Batch Processing**: Process multiple images at once, but stay within the 25-image limit
7. **Download Results**: Always download prompts before closing - they're not saved automatically

## 🐛 Known Issues

- Some websites with strict CORS policies may block image scraping
- Very large images (>10MB) may fail to process
- Rate limiting may occur if too many requests are made quickly
- Iframe-restricted websites cannot be scraped directly

## 📝 Changelog

### Version 1.3.0
- Added Trends tab with Shutterstock integration
- Improved API key validation and management
- Enhanced error handling and retry logic
- Better UI/UX with toast notifications
- Download functionality for trends page

### Version 1.2.0
- Added Magic Prompt feature
- Multiple artistic style options
- Improved prompt quality
- Better batch processing

### Version 1.1.0
- API key rotation system
- Bulk key input
- Auto-validation
- Enhanced error handling

### Version 1.0.0
- Initial release
- Basic image scraping
- Prompt generation
- File upload support

## 📞 Support

For issues, suggestions, or questions:
- Check the troubleshooting section above
- Review console logs (F12 → Console)
- Verify API key and quota status
- Ensure extension is up to date

## �‍💻 Author

**Aron Muhammad**

Developer and creator of Gemini Image Prompt Generator Chrome Extension.

## �📄 License

This extension is provided as-is for educational and personal use.

---

**Note**: This extension requires a valid Gemini API key to function. API usage is subject to Google's terms and rate limits. For best results, use multiple API keys and stay within recommended usage limits.

**Powered by Google Gemini 2.5** 🚀
